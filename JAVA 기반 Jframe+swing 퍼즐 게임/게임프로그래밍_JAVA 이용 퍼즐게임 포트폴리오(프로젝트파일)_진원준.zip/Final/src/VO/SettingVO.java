package VO;

/**
 * this VO class used to make Stage
 * @author PPPSH
 *
 */
public class SettingVO {
		private String stage;
		private String panelName;
		private String StepName;
		private String comboList[];
		
		public SettingVO(String stage ,String panel,String step, String[] list){
			this.stage=stage;
			this.panelName=panel;
			this.StepName = step;
			this.comboList= list;
		}
		
		
		public String getStage() {
			return stage;
		}

		public void setStage(String stage) {
			this.stage = stage;
		}
		public String getPanelName() {
			return panelName;
		}
		public void setPanelName(String panelName) {
			this.panelName = panelName;
		}
		public String getStepName() {
			return StepName;
		}
		public void setStepName(String stepName) {
			StepName = stepName;
		}
		public String[] getComboList() {
			return comboList;
		}
		public void setComboList(String[] comboList) {
			this.comboList = comboList;
		}
}
