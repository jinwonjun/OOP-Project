package GUI;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import EasyConcept.Stringg;
import EasyConcept.doublee;
import EasyConcept.intt;
import EasyConcept.shortt;
import HardConcept.forConcept;
import HardConcept.ifConcept;
import HardConcept.whileIdea;
import Interface.PInterface;
import NormalConcept.methodConcept;
import Quiz.src.EasyQuiz_1;
import Quiz.src.HardQuiz_1;
import Quiz.src.NormalQuiz_1;
import VO.SettingVO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;

/**
 * This class make Easy, Normal, Hard Frame using VO class
 * VO Class has String stage, panelName, StepName, comboList[]
 * @author PPPSH
 *
 */
public class StageFrame extends Stage{

	 private JTextArea concept;
	 private JPanel rightPanel;
	 private JPanel leftPanel;
	 private JPanel panel ;
	 private JComboBox comboBox ;
	 private JButton btnQuiz;
	 private SettingVO vo;
	 
	
	public StageFrame(SettingVO vo){
		this.vo=vo;
		init();
	}

	public void init(){
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Auto end
		this.setSize(1000,725);
		getContentPane().setLayout(null);
		panel = new JPanel();
		panel.setBounds(6, 79, 994, 615);
		getContentPane().add(panel);
		panel.setLayout(null);
		this.setVisible(true);
		
		leftPanel = new JPanel();
		leftPanel.setBackground(Color.YELLOW);
		leftPanel.setBounds(29, 54, 459, 518);
		panel.add(leftPanel);
		leftPanel.setLayout(null);
		
		
		concept = new JTextArea(); //JTextArea(Auto line enter) vs JTextField 
		concept.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		concept.setEditable(false);
		concept.setText(" Plese Click  'Choice!' and than when                            you finish the study, Go to Quiz");
		concept.setBounds(27, 33, 397, 263);
		leftPanel.add(concept);
		concept.setColumns(10);
		concept.setLineWrap(true);
		concept.setColumns(10);
		
		rightPanel = new JPanel();
		rightPanel.setBackground(Color.WHITE);
		
		rightPanel.setBounds(538, 54, 435, 522);
		panel.add(rightPanel);
		rightPanel.setLayout(null);
		
		
		 
	    
	      JLabel IdeaTitle1 = new JLabel("Let's go ");
	      IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 30));
	      IdeaTitle1.setBounds(28, 13, 152, 44);
	      rightPanel.add(IdeaTitle1);
	         
	      JLabel IdeaTitle2 = new JLabel("With ME ! I'm very Kind !");
	      IdeaTitle2.setForeground(Color.BLUE);
	      IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 30));
	      IdeaTitle2.setBounds(16, 54, 413, 48);
	      rightPanel.add(IdeaTitle2);
	        
	      JLabel az = new JLabel("");
	      az.setBounds(66, 116, 291, 334);
	      az.setIcon(new ImageIcon("src/res/az.png"));
          rightPanel.add(az);
	   	
		
		


		JLabel panelName = new JLabel(vo.getPanelName());
		panelName.setBounds(442, 22, 289, 16);
		getContentPane().add(panelName);
		
		JLabel stepName = new JLabel(vo.getStepName());
		stepName.setBounds(382, 32, 111, 55);
		getContentPane().add(stepName);
		
		
		comboBox = new JComboBox(vo.getComboList());
		comboBox.setBounds(488, 37, 281, 46);
		getContentPane().add(comboBox);
		
		btnQuiz = new JButton("Quiz");
		btnQuiz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goQuiz();
			}
		});
		
		btnQuiz.setBounds(811, 38, 117, 29);
		getContentPane().add(btnQuiz);
		buttonSetting();

	}

	//fr =FileRead
	public void buttonSetting(){
		comboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String checked=comboBox.getSelectedItem().toString();
					String txt="";
					ArrayList<String> list = new ArrayList<>();
					
				if(checked.equals("String")){
					list =fr.getTxt("string");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new Stringg());
					
				}else if(checked.equals("int")){
					list =fr.getTxt("int");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new intt());

				}else if(checked.equals("short")){
					list =fr.getTxt("short");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new shortt());

				
				}else if(checked.equals("double")){
					list =fr.getTxt("double");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new doublee());
				}else if(checked.equals("What a Method")){
					list =fr.getTxt("what method");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					
					changePanel(new methodConcept());
					
				}else if(checked.equals("How Method")){
					list =fr.getTxt("how method");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new methodConcept());	
				}else if(checked.equals("Why Method")){
					list =fr.getTxt("why method");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);	
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new methodConcept());
				}else if(checked.equals("For")){
					list =fr.getTxt("For");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new forConcept());
				}else if(checked.equals("If")){
					list =fr.getTxt("if else");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new ifConcept());

				}else if(checked.equals("While")){
					list =fr.getTxt("while");
					for(String x : list){
						txt = txt+" "+x;
					} 
					concept.setText(txt);
					fr.resetList();
					rightPanel.setVisible(false);
					changePanel(new whileIdea());	
				}else if(checked.equals("Choice!")){
					concept.setText(" Plese Click  'Choice!' and than when                            you finish the study, Go to Quiz");
					
					rightPanel.setVisible(false);
					changePanel(new HI());
				}
			}
		});	
	}
	
	
	public void goQuiz(){
		if(vo.getStage().equals("Easy")){
			new EasyQuiz_1();
		}else if(vo.getStage().equals("Normal")){
			new NormalQuiz_1();
		}else if(vo.getStage().equals("Hard")){
			new HardQuiz_1();
		}
		dispose();
	}
	
	
	//Applying  Polymorphism 
	public void changePanel(PInterface pi) 
    {
    	rightPanel=pi.getPanel();
    	panel.add(rightPanel);
        rightPanel.setVisible(true);
    }
    
    
	
}
