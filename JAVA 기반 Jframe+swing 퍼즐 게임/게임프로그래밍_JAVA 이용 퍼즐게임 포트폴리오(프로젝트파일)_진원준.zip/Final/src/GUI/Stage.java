package GUI;


import javax.swing.JFrame;
import Interface.PInterface;

/**
 * this is Interface.
 * To compel implements about Frame
 * and children class using FileRead
 *  
 * 
 * @author PPPSH
 *
 */
public abstract class Stage extends JFrame {
	
	 
	 FileRead fr = new FileRead();
	 
	 public abstract void goQuiz();
     public abstract void buttonSetting();
	 public abstract void changePanel(PInterface pi); 
	    
	    
}
