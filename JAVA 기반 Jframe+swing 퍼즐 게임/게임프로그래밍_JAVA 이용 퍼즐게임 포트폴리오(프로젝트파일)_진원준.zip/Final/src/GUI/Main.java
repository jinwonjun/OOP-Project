package GUI;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 * this class main Frame 
 * user choice 'Start' or 'Exit'
 * 
 * @author PPPSH
 *
 */
public class Main extends JFrame {

			public Main(){
				this.setResizable(false);
				this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				this.setSize(1000,600);
				JPanel mainPanel = new JPanel();
				getContentPane().add(mainPanel, BorderLayout.CENTER);
				mainPanel.setLayout(null);
				
				JButton startBtn = new JButton("Start");
				startBtn.setBounds(815, 299, 136, 89);
				mainPanel.add(startBtn);
				startBtn.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						new Start();
						dispose();
					}
				});
				
				JButton exitBtn = new JButton("Exit");
				exitBtn.setBounds(815, 429, 136, 89);
				mainPanel.add(exitBtn);
				exitBtn.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						dispose();	
					}
				});
				
				JLabel mainLabel = new JLabel("");
				mainLabel.setIcon(new ImageIcon("src/res/teemu.jpg"));
				mainLabel.setBounds(25, 6, 667, 538);
				mainPanel.add(mainLabel);
				this.setVisible(true);
				
				
			}
	
			public static void main(String[] args) {
				new Main();
			}
}
