package GUI;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Password.Password;
import VO.SettingVO;

/**
 * Choice Start, Normal, Hard
 * @author PPPSH
 *
 */
public class Start extends JFrame {

	JButton easyBtn;
	JButton normalBtn;
	JButton hardBtn;

	JFrame passPop;

	int normalPass;
	int hardPass;

	public Start() {
		Password pass = Password.getPass();   //Singleton pattern
		normalPass = pass.getNormal();
		hardPass = pass.getHard();
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1000, 600);
		getContentPane().setLayout(null);

		JPanel startPanel = new JPanel();
		startPanel.setBounds(34, 10, 1000, 578);
		getContentPane().add(startPanel);
		startPanel.setLayout(null);
		System.out.println(normalPass);
		System.out.println(hardPass);

		
		
		//Easy stage Setting
		JButton easyButton = new JButton("EASY");
		easyButton.setFont(new Font("Elephant", Font.ITALIC, 32));
		easyButton.setBounds(46, 130, 233, 266);
		startPanel.add(easyButton);
		easyButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String stage = "Easy";
				String p = "We Start about Variable";
				String step = "Easy Step!";
				String[] list = { "Choice!", "String", "short", "int", "double" };
				new StageFrame(new SettingVO(stage, p, step, list));
				dispose();
			}
		});

		
		//Normal stage Setting
		JButton normalBtn = new JButton("Normal");
		normalBtn.setFont(new Font("Elephant", Font.PLAIN, 32));
		normalBtn.setBounds(349, 126, 233, 274);
		startPanel.add(normalBtn);
		normalBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				passPop = new JFrame();
				JTextField inputPass;
				JButton conPass;
				passPop.setVisible(true);
				passPop.setSize(200, 200);
				JPanel passPanel = new JPanel();
				passPop.setContentPane(passPanel);
				passPanel.add(new JLabel("INPUT PASSWORD !"));
				passPanel.add(inputPass = new JTextField(15));
				passPanel.add(conPass = new JButton("SUBMIT!"));
				conPass.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if (inputPass.getText().equals(String.valueOf(normalPass))) {
							passPop.dispose();
							String stage = "Normal";
							String p = "We Start about Method";
							String step = "Normal Step!";
							String[] list = { "Choice!", "What a Method", "How Method", "Why Method" };
							new StageFrame(new SettingVO(stage, p, step, list));
							dispose();
						} else {

							JOptionPane.showMessageDialog(passPop, "Wrong Password, Get on before Step! ");
							passPop.dispose();
						}

					}
				});
			}

		});

		
		
		//Hard stage Setting
		hardBtn = new JButton("Hard");
		hardBtn.setFont(new Font("Elephant", Font.ITALIC, 32));
		hardBtn.setBounds(658, 126, 233, 274);
		startPanel.add(hardBtn);

		JLabel lblNewLabel = new JLabel("            LEVEL SELECT");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 32));
		lblNewLabel.setBounds(264, 23, 403, 93);
		startPanel.add(lblNewLabel);

		hardBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				passPop = new JFrame();
				JTextField inputPass;
				JButton conPass;
				passPop.setVisible(true);
				passPop.setSize(200, 200);
				JPanel passPanel = new JPanel();
				passPop.setContentPane(passPanel);
				passPanel.add(new JLabel("INPUT PASSWORD !"));
				passPanel.add(inputPass = new JTextField(15));
				passPanel.add(conPass = new JButton("SUBMIT!"));
				conPass.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {

						if (inputPass.getText().equals(String.valueOf(hardPass))) {
							passPop.dispose();
							String stage = "Hard";
							String p = "We Start about For , If , While ";
							String step = "Normal Step!";
							String[] list = { "Choice!", "For", "If", "While" };
							new StageFrame(new SettingVO(stage, p, step, list));
							dispose();
						} else {
							JOptionPane.showMessageDialog(passPop, "Wrong Password, Get on before Step! ");
							passPop.dispose();
						}

					}
				});
			}
		});
		this.setVisible(true);
	}
}
