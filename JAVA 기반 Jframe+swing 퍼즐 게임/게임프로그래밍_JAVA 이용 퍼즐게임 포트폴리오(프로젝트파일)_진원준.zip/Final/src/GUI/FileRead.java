package GUI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;



/**
 * In this class , MainFrame leftPanel's component is made.
 * This class read the text file and return text using ArrayList<String>
 * Using bufferedReader.
 * 
 * resetList() clear the ArrayList
 *  
 * @author PPPSH
 *
 */
public class FileRead {
	
	private ArrayList<String> txt = new ArrayList<String>(); //written data storage
	
	public ArrayList<String> getTxt(String x) {
		FileRead fr = new FileRead();
		String path="src/res/"+x+".txt";
		BufferedReader br=null;
		try {								//About file not found exception handling
			br=new BufferedReader(new FileReader(path));
			String str=br.readLine();
			while(str!=null){
				this.txt.add(str);           //add to Arraylist , to use StageFrame's leftPanel contents 
				str=br.readLine();
			}
		} catch (FileNotFoundException e) {			
			e.printStackTrace();
		} catch (IOException e) {			
			e.printStackTrace();
		}finally{
			try {
				if(br!=null)
				br.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}	
		return this.txt;
	}
	
	public void resetList(){
		this.txt.clear();   //arrayList initialize
	}
	
	
	
	
	
	
}
