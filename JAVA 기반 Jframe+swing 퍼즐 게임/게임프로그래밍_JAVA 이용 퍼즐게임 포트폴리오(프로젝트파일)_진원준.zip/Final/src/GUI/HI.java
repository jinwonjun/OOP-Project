package GUI;

import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Interface.PInterface;


/**
 * this class about MainFrame's Right panel
 * when user check comboBox 'Choice!'
 * this panel is not explain, Just manual and refresh. 
 * 
 * @author PPPSH
 *
 */
public class HI extends JPanel implements PInterface {

	
	public JPanel panel= new JPanel();
	
	public HI(){

		  panel.setBounds(538, 70, 435, 410);
	      panel.setLayout(null);
	      
	      JLabel IdeaTitle1 = new JLabel("Let's go ");
	      IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 30));
	      IdeaTitle1.setBounds(12, 13, 152, 44);
	      this.panel.add(IdeaTitle1);
	         
	      JLabel IdeaTitle2 = new JLabel("With ME ! I'm very Kind !");
	      IdeaTitle2.setForeground(Color.BLUE);
	      IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 30));
	      IdeaTitle2.setBounds(22, 57, 396, 48);
	      this.panel.add(IdeaTitle2);
	        
	      JLabel az = new JLabel("");
	      az.setBounds(22, 115, 396, 289);
	      az.setIcon(new ImageIcon("src/res/az.png"));   //main pic
          panel.add(az);
          
	   	
	}
	//return panel
	public JPanel getPanel() {
		return this.panel;
	}
}
