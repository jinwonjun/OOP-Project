package EasyConcept;


import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Interface.PInterface;

/**
 * this class about MainFrame's Right panel
 * when user check comboBox 'int'
 * this panel explains about 'int variable' using Graphic
 * @author PPPSH
 *
 */
public class intt extends JPanel implements PInterface{
	public JPanel panel = new JPanel();
	/**
	 * Create the frame.
	 */
	public intt() {
		panel.setBounds(538, 70, 435, 410);
		panel.setLayout(null);
		JLabel cycle = new JLabel("");
		cycle.setIcon(new ImageIcon("src/res/cycle.png"));   // intt up Pic
		cycle.setBounds(247, 207, 160, 105);
		this.panel.add(cycle);
		
		JLabel lblNewLabel_3 = new JLabel("\"We can ride This!\"");  //      inner up text
		lblNewLabel_3.setForeground(Color.GREEN);
		lblNewLabel_3.setFont(new Font("�޸�����ü", Font.BOLD, 25));
		lblNewLabel_3.setBounds(95, 109, 272, 30);
		this.panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("But, We can't ride Bike!");        //inner text
		lblNewLabel_4.setFont(new Font("�޸�����ü", Font.BOLD, 20));
		lblNewLabel_4.setForeground(Color.RED);
		lblNewLabel_4.setBounds(95, 149, 259, 24);
		this.panel.add(lblNewLabel_4);
		
		 JLabel IdeaTitle1 = new JLabel("What is");								//inner text
	     IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 30));
	     IdeaTitle1.setBounds(56, 13, 174, 35);
	     this.panel.add(IdeaTitle1);
	      
	     JLabel IdeaTitle2 = new JLabel("int?");
	     IdeaTitle2.setForeground(Color.BLUE);
	     IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 35));
	     IdeaTitle2.setBounds(197, 7, 192, 42);
	     this.panel.add(IdeaTitle2);
	     
	     JLabel youth = new JLabel("");
	     youth.setIcon(new ImageIcon("src/res/youth.png"));				//    intt down Pic
	     youth.setBounds(12, 246, 250, 154);
	     this.panel.add(youth);
	     
	     JLabel balloon2 = new JLabel("");								//balloon2 pic
	     balloon2.setIcon(new ImageIcon("src/res/balloon2.png"));
	     balloon2.setBounds(71, 42, 283, 253);
	     this.panel.add(balloon2);
		
		
		
	}
	
	//return this panel
	public JPanel getPanel(){
		return this.panel;
	}

}
