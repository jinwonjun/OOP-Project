package EasyConcept;


import java.awt.Color;
import java.awt.Font;
import javax.swing.JPanel;
import Interface.PInterface;
import javax.swing.JLabel;
import javax.swing.ImageIcon;


/**
 * this class about MainFrame's Right panel
 * when user check comboBox 'short'
 * this panel explains about 'short variable' using Graphic
 * @author PPPSH
 *
 */
public class shortt extends JPanel implements PInterface{

	
	public JPanel panel = new JPanel();
	
	
	public shortt() {
		panel.setBounds(538, 70, 435, 410);
		panel.setLayout(null);
		
		JLabel minibike = new JLabel("");
		minibike.setIcon(new ImageIcon("src/res/minibike.png"));
		minibike.setBounds(261, 216, 120, 142);
		panel.add(minibike);
		
		
		JLabel lblNewLabel_4 = new JLabel("But, We can't ride Cycle, Bike!");
		lblNewLabel_4.setFont(new Font("�޸�����ü", Font.BOLD, 20));
		lblNewLabel_4.setForeground(Color.RED);
		lblNewLabel_4.setBounds(58, 180, 323, 24);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_3 = new JLabel("\"We can ride This!\"");
		lblNewLabel_3.setForeground(Color.GREEN);
		lblNewLabel_3.setFont(new Font("�޸�����ü", Font.BOLD, 25));
		lblNewLabel_3.setBounds(84, 122, 253, 30);
		panel.add(lblNewLabel_3);
		
		JLabel balloon2 = new JLabel("");
		balloon2.setIcon(new ImageIcon("src/res/balloon2.png"));
		balloon2.setBounds(85, 64, 283, 253);
		panel.add(balloon2);		
		
		JLabel child = new JLabel("");
		child.setIcon(new ImageIcon("src/res/child.png"));
		child.setBounds(0, 272, 200, 128);
		panel.add(child);
		
		
		 JLabel IdeaTitle1 = new JLabel("What is");
	     IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 30));
	     IdeaTitle1.setBounds(40, 3, 144, 35);
	     panel.add(IdeaTitle1);
	      
	     JLabel IdeaTitle2 = new JLabel("short?");
	     IdeaTitle2.setForeground(Color.BLUE);
	     IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 35));
	     IdeaTitle2.setBounds(180, -3, 138, 42);
	     panel.add(IdeaTitle2);
	}
	
	public JPanel getPanel(){
		return this.panel;
	}

}
