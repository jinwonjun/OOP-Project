package EasyConcept;


import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Interface.PInterface;



/**
 * this class about MainFrame's Right panel
 * when user check comboBox 'double'
 * this panel explains about double using Graphic
 * because this inherits 'PInterface' , so implements getPanel to send panel 
 * @author PPPSH
 *
 */
public class doublee extends JPanel implements PInterface{

	
	//component about StageFrame's rightPanel
	public JPanel panel= new JPanel();
		
	public doublee() {
		panel.setBounds(538, 70, 435, 410);
		panel.setLayout(null);
		
		JLabel bike = new JLabel("");
		bike.setIcon(new ImageIcon("src/res/bike.png"));   //in RightPanel Pic
		bike.setBounds(252, 195, 150, 158);
		panel.add(bike);
		
		JLabel IdeaTitle1 = new JLabel("What is");
	    IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 30));
	    IdeaTitle1.setBounds(33, 3, 150, 35);
	    panel.add(IdeaTitle1);
	      
	    JLabel IdeaTitle2 = new JLabel("double?");
        IdeaTitle2.setForeground(Color.BLUE);
	    IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 35));
	    IdeaTitle2.setBounds(168, -3, 164, 42);
	    panel.add(IdeaTitle2);
	     
	    JLabel lblNewLabel_3 = new JLabel("\"I can ride This!\"");
	    lblNewLabel_3.setForeground(Color.GREEN);
	    lblNewLabel_3.setFont(new Font("�޸�����ü", Font.BOLD, 25));
	    lblNewLabel_3.setBounds(74, 100, 272, 30);
	    panel.add(lblNewLabel_3);
	     
	     JLabel lblNewLabel_4 = new JLabel("I can ride Whatever HAHA!");
		 lblNewLabel_4.setFont(new Font("�޸�����ü", Font.BOLD, 20));
		 lblNewLabel_4.setForeground(Color.RED);
		 lblNewLabel_4.setBounds(63, 168, 339, 24);
		 panel.add(lblNewLabel_4);
	     
		 JLabel rider = new JLabel("");
		 rider.setIcon(new ImageIcon("src/res/rider.png")); 
		 rider.setBounds(0, 216, 230, 184);
	     panel.add(rider);
		     
	     JLabel balloon2 = new JLabel("");
	     balloon2.setIcon(new ImageIcon("src/res/balloon2.png"));
	     balloon2.setBounds(83, 48, 283, 253);	
	     panel.add(balloon2);
		
	}
	
	
	public JPanel getPanel(){
		return this.panel;
	}

}
