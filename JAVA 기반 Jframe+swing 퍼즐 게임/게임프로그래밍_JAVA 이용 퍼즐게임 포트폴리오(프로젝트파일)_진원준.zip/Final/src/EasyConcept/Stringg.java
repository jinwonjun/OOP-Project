package EasyConcept;

import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Interface.PInterface;

/**
 * this class about MainFrame's Right panel when user check comboBox 'String'
 * this panel explains about 'short variable' using Graphic
 * @author PPPSH
 *
 */
public class Stringg extends JPanel implements PInterface {

	public JPanel panel = new JPanel();

	public Stringg() {

		panel.setBounds(538, 70, 435, 410);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("src/res/book.png"));
		lblNewLabel.setBounds(69, 129, 300, 271);
		this.panel.add(lblNewLabel);

		JLabel IdeaTitle1 = new JLabel("What is");
		IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 30));
		IdeaTitle1.setBounds(12, 13, 125, 30);
		this.panel.add(IdeaTitle1);

		JLabel IdeaTitle2 = new JLabel("String?");
		IdeaTitle2.setForeground(Color.BLUE);
		IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 35));
		IdeaTitle2.setBounds(139, 10, 132, 35);
		this.panel.add(IdeaTitle2);

	}

	@Override
	public JPanel getPanel() {
		return this.panel;
	}

}