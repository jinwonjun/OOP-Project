package HardConcept;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Interface.PInterface;

import javax.swing.ImageIcon;

public class whileIdea extends JFrame implements PInterface{

	private JPanel panel = new JPanel();


	public whileIdea() {
		panel.setBounds(538, 50, 435, 410);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Run until Turn off button!");
		lblNewLabel_1.setForeground(Color.MAGENTA);
		lblNewLabel_1.setFont(new Font("�޸�����ü", Font.BOLD, 20));
		lblNewLabel_1.setBounds(118, 72, 278, 50);
		panel.add(lblNewLabel_1);
		
		JLabel IdeaTitle1 = new JLabel("What is");
		IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 25));
		IdeaTitle1.setBounds(0, 0, 94, 42);
		panel.add(IdeaTitle1);
		
		JLabel IdeaTitle2 = new JLabel("While?");
		IdeaTitle2.setForeground(Color.BLUE);
		IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 30));
		IdeaTitle2.setBounds(97, 0, 115, 43);
		panel.add(IdeaTitle2);
		
		JLabel run = new JLabel("");
		run.setIcon(new ImageIcon("src/res/run.png"));
		run.setBounds(0, 201, 250, 209);
		panel.add(run);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("src/res/balloon1.png"));
		lblNewLabel.setBounds(95, 0, 340, 304);
		panel.add(lblNewLabel);
	}

	public JPanel getPanel(){
		return this.panel;
	}

}
