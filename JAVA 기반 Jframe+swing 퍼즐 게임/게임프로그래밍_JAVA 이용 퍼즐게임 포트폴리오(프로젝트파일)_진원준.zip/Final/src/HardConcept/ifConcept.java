package HardConcept;


import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Interface.PInterface;
import javax.swing.ImageIcon;




public class ifConcept extends JPanel implements PInterface{

	private JPanel panel = new JPanel();


	public ifConcept() {
		panel.setBounds(538, 50, 435, 410);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("...if???");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("�޸�����ü", Font.BOLD, 30));
		lblNewLabel.setBounds(231, 53, 81, 60);
		panel.add(lblNewLabel);
		
		JLabel IdeaTitle1 = new JLabel("What is");
		IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 25));
		IdeaTitle1.setBounds(0, 0, 94, 42);
		panel.add(IdeaTitle1);
		
		JLabel IdeaTitle2 = new JLabel("if?");
		IdeaTitle2.setForeground(Color.BLUE);
		IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 30));
		IdeaTitle2.setBounds(97, 0, 57, 43);
		panel.add(IdeaTitle2);
		
		JLabel lblNewThink = new JLabel("");
		lblNewThink.setIcon(new ImageIcon("src/res/think.png"));
		lblNewThink.setBounds(0, 152, 200, 248);
		panel.add(lblNewThink);
		
		JLabel lblNewBalloon = new JLabel("");
		lblNewBalloon.setIcon(new ImageIcon("src/res/balloon.png"));
		lblNewBalloon.setBounds(202, 10, 156, 180);
		panel.add(lblNewBalloon);
	}
	public JPanel getPanel(){
		return this.panel;
	}

}
