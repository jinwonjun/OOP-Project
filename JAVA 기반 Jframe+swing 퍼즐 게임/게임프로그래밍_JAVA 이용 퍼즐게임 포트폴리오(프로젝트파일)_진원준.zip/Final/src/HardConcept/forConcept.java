package HardConcept;


import javax.swing.JPanel;
import Interface.PInterface;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * about 'for' panel
 * @author PPPSH
 *
 */
public class forConcept extends JPanel implements PInterface{



   private JLabel forIdea1;
   private JLabel forIdea2;
   private JLabel forIdea3;
   private JLabel forIdea4;
   private JLabel forIdea5;
   private JButton repeat;
   
   private JPanel panel = new JPanel(); 
   public String conceptTexts[] = {"long", "double", "int", "short", "test2"};
  
   public forConcept() {
	   panel.setBounds(538, 50, 435, 497);
		panel.setLayout(null);
	   
	  JLabel mario2 = new JLabel("");
      mario2.setIcon(new ImageIcon("src/res/mario.png"));
      mario2.setBounds(49, 204, 80, 97);
	  mario2.setVisible(false);
	      panel.add(mario2);
	      
      JLabel IdeaTitle1 = new JLabel("What is");
      IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 25));
      IdeaTitle1.setBounds(0, 0, 94, 42);
      panel.add(IdeaTitle1);
      
      JLabel IdeaTitle2 = new JLabel("for?");
      IdeaTitle2.setForeground(Color.BLUE);
      IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 30));
      IdeaTitle2.setBounds(97, 0, 72, 43);
      panel.add(IdeaTitle2);
      
      JLabel lblNewLabel = new JLabel("(Total Step) (Up Step)");
      lblNewLabel.setFont(new Font("�޸�����ü", Font.BOLD, 16));
      lblNewLabel.setBounds(149, 437, 183, 33);
      panel.add(lblNewLabel);
      
      JLabel lblNewLabel_1 = new JLabel("(First Step)");
      lblNewLabel_1.setFont(new Font("�޸�����ü", Font.BOLD, 16));
      lblNewLabel_1.setBounds(49, 441, 94, 25);
      panel.add(lblNewLabel_1);
      
      JLabel lblNewLabel_2 = new JLabel("(Second Step)");
      lblNewLabel_2.setFont(new Font("�޸�����ü", Font.BOLD, 16));
      lblNewLabel_2.setBounds(30, 441, 120, 25);
      lblNewLabel_2.setVisible(false);
      panel.add(lblNewLabel_2);
      
      JLabel lblNewLabel_3 = new JLabel("(Third Step)");
      lblNewLabel_3.setFont(new Font("�޸�����ü", Font.BOLD, 16));
      lblNewLabel_3.setBounds(49, 441,120, 25);
      lblNewLabel_3.setVisible(false);
      panel.add(lblNewLabel_3);
      
      JLabel lblNewLabel_4 = new JLabel("(Forth Step)");
      lblNewLabel_4.setFont(new Font("�޸�����ü", Font.BOLD, 16));
      lblNewLabel_4.setBounds(49, 441, 120, 25);
      lblNewLabel_4.setVisible(false);
      panel.add(lblNewLabel_4);
      
      JLabel lblNewLabel_5 = new JLabel("(Fifth Step)");
      lblNewLabel_5.setFont(new Font("�޸�����ü", Font.BOLD, 16));
      lblNewLabel_5.setBounds(49, 441, 120, 25);
      lblNewLabel_5.setVisible(false);
      panel.add(lblNewLabel_5);
      
      
      JLabel totalStep = new JLabel("\u2191");
      totalStep.setForeground(Color.BLUE);
      totalStep.setFont(new Font("�޸�����ü", Font.BOLD, 20));
      totalStep.setBounds(181, 423, 16, 33);
      panel.add(totalStep);
      
      JLabel firstStep = new JLabel("\u2191");
      firstStep.setForeground(Color.BLUE);
      firstStep.setFont(new Font("�޸�����ü", Font.BOLD, 20));
      firstStep.setBounds(112, 423, 16, 33);
      panel.add(firstStep);
      
      JLabel upStep = new JLabel("\u2191");
      upStep.setForeground(Color.BLUE);
      upStep.setFont(new Font("�޸�����ü", Font.BOLD, 20));
      upStep.setBounds(253, 423, 16, 33);
      panel.add(upStep);
      

      JLabel step = new JLabel("");
      step.setIcon(new ImageIcon("src/res/stair.png"));
      step.setBounds(95, 88, 273, 290);
      panel.add(step);
      
      JLabel mario3 = new JLabel("");
      mario3.setIcon(new ImageIcon("src/res/mario.png"));
      mario3.setBounds(123, 136, 80, 97);
      mario3.setVisible(false);
      panel.add(mario3);
      
      JLabel mario1 = new JLabel("");
      mario1.setIcon(new ImageIcon("src/res/mario.png"));
      mario1.setBounds(-18, 281, 80, 97);
      panel.add(mario1);
      
      JLabel mario4 = new JLabel("");
      mario4.setIcon(new ImageIcon("src/res/mario.png"));
      mario4.setBounds(192, 64, 80, 97);
      mario4.setVisible(false);
      panel.add(mario4);
      
      JLabel mario5 = new JLabel("");
      mario5.setIcon(new ImageIcon("src/res/mario.png"));
      mario5.setBounds(253, 0, 80, 97);
      mario5.setVisible(false);
      panel.add(mario5);
      
      JLabel forIdea = new JLabel("for( i=0 ; i<5 ; i++)");
      forIdea.setFont(new Font("�޸�����ü", Font.BOLD, 25));
      forIdea.setBounds(31, 367, 290, 79);
      panel.add(forIdea);
      
      JButton btnNewButton1 = new JButton("Play!");
      btnNewButton1.setBounds(10, 54, 94, 87);
      
      panel.add(btnNewButton1);
      
      JButton btnNewButton2 = new JButton("Play!");
      btnNewButton2.setBounds(10, 54, 94, 87);
      btnNewButton2.setVisible(false);
      panel.add(btnNewButton2);
      
      JButton btnNewButton3 = new JButton("Play!");
      btnNewButton3.setBounds(10, 54, 94, 87);
      btnNewButton3.setVisible(false);
      panel.add(btnNewButton3);
      
      JButton btnNewButton4 = new JButton("Play!");
      btnNewButton4.setBounds(10, 54, 94, 87);
      btnNewButton4.setVisible(false);
      panel.add(btnNewButton4);
     
      
      btnNewButton1.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            if(e.getSource()==btnNewButton1)
            {
               mario1.setVisible(false);
               forIdea.setVisible(false);
               mario2.setVisible(true);
               
               lblNewLabel_1.setVisible(false);
               lblNewLabel_2.setVisible(true);
               
               forIdea2 = new JLabel("for( i=1 ; i<5 ; i++)");
               forIdea2.setFont(new Font("�޸�����ü", Font.BOLD, 25));
               forIdea2.setBounds(31, 367, 290, 79);
               panel.add(forIdea2);
               btnNewButton1.setVisible(false);
               btnNewButton2.setVisible(true);
               
            }
         }
      });
      btnNewButton2.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            if(e.getSource()==btnNewButton2)
            {
               mario2.setVisible(false);
               forIdea2.setVisible(false);
               mario3.setVisible(true);
               
               lblNewLabel_2.setVisible(false);
               lblNewLabel_3.setVisible(true);
               
               forIdea3 = new JLabel("for( i=2 ; i<5 ; i++)");
               forIdea3.setFont(new Font("�޸�����ü", Font.BOLD, 25));
               forIdea3.setBounds(31, 367, 290, 79);
               panel.add(forIdea3);
               btnNewButton2.setVisible(false);
               btnNewButton3.setVisible(true);
               
            }
         }
      });
      btnNewButton3.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            if(e.getSource()==btnNewButton3)
            {
               mario3.setVisible(false);
               forIdea3.setVisible(false);
               mario4.setVisible(true);
               
               lblNewLabel_3.setVisible(false);
               lblNewLabel_4.setVisible(true);
               
               forIdea4 = new JLabel("for( i=3 ; i<5 ; i++)");
               forIdea4.setFont(new Font("�޸�����ü", Font.BOLD, 25));
               forIdea4.setBounds(31, 367, 290, 79);
               panel.add(forIdea4);
               btnNewButton3.setVisible(false);
               btnNewButton4.setVisible(true);
            }
         }
      });
      btnNewButton4.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            if(e.getSource()==btnNewButton4)
            {
               mario4.setVisible(false);
               forIdea4.setVisible(false);
               mario5.setVisible(true);
               
               lblNewLabel_4.setVisible(false);
               lblNewLabel_5.setVisible(true);
               
               forIdea5 = new JLabel("for( i=4 ; i<5 ; i++)");
               forIdea5.setFont(new Font("�޸�����ü", Font.BOLD, 25));
               forIdea5.setBounds(31, 367, 290, 79);
               panel.add(forIdea5);
               btnNewButton4.setVisible(false);
              
              
            }
         }
      });
      
   
}
	public JPanel getPanel(){
		return this.panel;
	}

   
}