package Quiz.src;

import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class HardQuiz_1 extends JFrame implements ActionListener,ItemListener{
		int answer=2; //1,2,3,4 setting answer
		int choosed;
		JFrame frame;
		JRadioButton check1;
		JRadioButton check2;
		JRadioButton check3;
		JRadioButton check4;
		JLabel label;
		private final ButtonGroup buttonGroup = new ButtonGroup();
		
	public HardQuiz_1(){
		frame = new JFrame();
		JButton button = new JButton("Submit");
		button.addActionListener(this);
		check1 = new JRadioButton("if(b==5)");
		buttonGroup.add(check1);
		check2 = new JRadioButton("if(a==5)");
		buttonGroup.add(check2);
		check3 = new JRadioButton("if(a==b)");
		buttonGroup.add(check3);
		check4 = new JRadioButton("if(b!=3)");
		buttonGroup.add(check4);
		label = new JLabel();	
		check1.addItemListener(this);
		check2.addItemListener(this);
		check3.addItemListener(this);
		check4.addItemListener(this);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container pane = frame.getContentPane();
		pane.setLayout(new BoxLayout(pane,BoxLayout.Y_AXIS));
		JLabel q=new JLabel("Question1");
		q.setFont(new Font("�޸�����ü", Font.PLAIN, 20));
		pane.add(q);
		JLabel p=new JLabel("There is a code.");
		p.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
		pane.add(p);
		JLabel p2=new JLabel("Which condition in 'here' can execute code?");
		p2.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
		pane.add(p2);
		pane.add(new JLabel("int a=5;"));
		pane.add(new JLabel("'here'{"));
		pane.add(new JLabel("System.out.println(a);"));
		pane.add(new JLabel("}"));
		pane.add(check1);
		pane.add(check2);
		pane.add(check3);
		pane.add(check4);
		pane.add(button);
		pane.add(label);
		frame.setSize(500, 500);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(choosed==answer){
			JOptionPane.showMessageDialog(null,"Correct!");
			//���� ������ �Ѿ�� �ڵ�
			frame.setVisible(false);
			HardQuiz_2 h2=new HardQuiz_2();
			h2.main(null);
		}
		else if(choosed==1){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"b is 3.\n"+"Try again");	
		}
		else if(choosed==3){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"a and b are different.\n"+"Try again");
		}
		else if(choosed==4){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"b is 3\n"+"Try again");
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		
		if (check1.isSelected()){
			choosed=1;
		}
		if (check2.isSelected()){
			choosed=2;
		}
		if(check3.isSelected()){
			choosed=3;
		}
		if(check4.isSelected()){
			choosed=4;
		}
	}
	
}
