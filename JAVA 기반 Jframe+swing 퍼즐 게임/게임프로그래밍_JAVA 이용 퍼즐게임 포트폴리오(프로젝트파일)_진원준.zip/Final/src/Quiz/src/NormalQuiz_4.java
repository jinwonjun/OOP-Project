package Quiz.src;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import GUI.Start;
import Password.Password;

public class NormalQuiz_4 extends JFrame {

   JPanel jp = new JPanel();   
   JButton button ;
   
   
   JLabel l1;
   JLabel l2;
   JLabel l3;
   
   JButton b1;
   JButton b2;
   JButton b3;
   
   JTextField t1;
   JTextField t2;
   JTextField t3;
   
   int hardPass;
   
   
   public NormalQuiz_4(){
	   
		  Password pass = Password.getPass();
		  hardPass=pass.getHard();
	      
      this.setResizable(false);
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setBounds(0, 0, 500, 473);
      jp.setLayout(new BoxLayout(jp,BoxLayout.Y_AXIS));
      int i = ((int)(Math.random()*10)/4);
      System.out.println(i);
      
      String[] text={("public static void main(String[] args){}"),("int add(int a,int b){return a+b;}"),("char bbb(char c){return c;}"),("double pi(){return 3.14;}")};
      
      this.setContentPane(jp);
      jp.add(l1=new JLabel(text[i]));
      JTextField t1 = new JTextField(30);
      t1.setBounds(0, 0, 100, 20);
      jp.add(t1);
      jp.add(button = new JButton("Submit"));
      button.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            if(t1.getText().equals(l1.getText())){
               JOptionPane.showMessageDialog(jp, "Correct! next Stage's PASSWORD"+"  "+hardPass);
               dispose();
               Start start= new Start();
               
               //setting password.
            }else{
               JOptionPane.showMessageDialog(jp, "Wrong!");
            }
         }
      });
      
      this.setVisible(true);
      
      
   }
   
   
   public void test1(){
      
   }
   
   
}
