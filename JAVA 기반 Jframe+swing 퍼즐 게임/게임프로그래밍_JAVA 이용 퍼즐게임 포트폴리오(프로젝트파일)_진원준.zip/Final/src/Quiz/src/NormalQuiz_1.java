package Quiz.src;


import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class NormalQuiz_1 extends JFrame implements ActionListener,ItemListener{
		int answer=3; //1,2,3,4 setting answer
		int choosed;
		JFrame frame;
		JRadioButton check1;
		JRadioButton check2;
		JRadioButton check3;
		JRadioButton check4;
		JLabel label;
		private final ButtonGroup buttonGroup = new ButtonGroup();
	public NormalQuiz_1(){
		frame = new JFrame();
		JButton button = new JButton("Submit");
		button.addActionListener(this);
		check1 = new JRadioButton("return pra;");
		buttonGroup.add(check1);
		check2 = new JRadioButton("return false;");
		buttonGroup.add(check2);
		check3 = new JRadioButton("return 3.14;");
		buttonGroup.add(check3);
		check4 = new JRadioButton("return 'j';");
		buttonGroup.add(check4);
		label = new JLabel();	
		check1.addItemListener(this);
		check2.addItemListener(this);
		check3.addItemListener(this);
		check4.addItemListener(this);
		Container pane = frame.getContentPane();
		pane.setLayout(new BoxLayout(pane,BoxLayout.Y_AXIS));
		JLabel q=new JLabel("Question1");
		q.setFont(new Font("�޸�����ü", Font.PLAIN, 20));
		pane.add(q);
		JLabel p=new JLabel("There is a method.");
		p.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
		pane.add(p);
		pane.add(new JLabel("double aaa(int pra){"));
		pane.add(new JLabel("'here'"));
		pane.add(new JLabel("}"));
		JLabel p3=new JLabel("In 'here',there will be return code.");
		p3.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
		pane.add(p3);
		JLabel p4=new JLabel("what is a right return code?");			
		p4.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
		pane.add(p4);
		pane.add(check1);
		pane.add(check2);
		pane.add(check3);
		pane.add(check4);
		pane.add(button);
		pane.add(label);
		frame.setSize(500, 500);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(choosed==answer){
			JOptionPane.showMessageDialog(null,"Correct!");
			//���� ������ �Ѿ�� �ڵ�
			frame.setVisible(false);
			NormalQuiz_2 n2=new NormalQuiz_2();
			n2.main(null);
			
		}
		else if(choosed==1){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"pra's type is int."+"Try again");
			
		}
		else if(choosed==2){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"false is one of the boolean type.\n"+"Try again");
		}
		else if(choosed==4){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"'j'is a char type.\n"+"Try again");
		}

	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
		if (check1.isSelected()){
			choosed=1;
			
		}
		if (check2.isSelected()){
			choosed=2;
		}
		if(check3.isSelected()){
			choosed=3;
		}
		if(check4.isSelected()){
			choosed=4;
		}
	}
	
}

