package Quiz.src;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class HardQuiz_2 extends JFrame
{
   private JPanel contentPane;
   private JTextField box1;
   private JTextField box2;
   private JTextField box3;
   private JTextField box4;


   public static void main(String[] args)
   {
      
      HardQuiz_2 frame = new HardQuiz_2();
               frame.setVisible(true);
            
   }
   
   
   public HardQuiz_2() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 500, 600);
      contentPane = new JPanel();
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setLayout(new BorderLayout(0, 0));
      setContentPane(contentPane);
      
      JPanel panel = new JPanel();
      contentPane.add(panel, BorderLayout.CENTER);
      panel.setLayout(null);
      
      
      JLabel q2problem = new JLabel("Make Program which can makes rectangle!");
      q2problem.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
      q2problem.setBounds(0, 51, 400, 24);
      panel.add(q2problem);
      JLabel lblNewLabel_5 = new JLabel("(4)System.out.println(��*****��);}");
      lblNewLabel_5.setBounds(104, 395, 300, 15);
      panel.add(lblNewLabel_5);
      
      JLabel lblNewLabel_4 = new JLabel("(3)for (int i = 0;");
      lblNewLabel_4.setBounds(104, 370, 114, 15);
      panel.add(lblNewLabel_4);
      
      JLabel lblNewLabel_3 = new JLabel("(2)i < 5 ;");
      lblNewLabel_3.setBounds(104, 345, 114, 15);
      panel.add(lblNewLabel_3);
      
      JLabel lblNewLabel_2 = new JLabel("(1) i++){");
      lblNewLabel_2.setBounds(104, 320, 67, 15);
      panel.add(lblNewLabel_2);
      
      JLabel computerpic = new JLabel("");
      computerpic.setIcon(new ImageIcon("src/res/HardQuiz_2.png"));
      computerpic.setBounds(0, 54, 333, 295);
      panel.add(computerpic);
      
      JLabel q2 = new JLabel("Question2");
      q2.setFont(new Font("�޸�����ü", Font.PLAIN, 20));
      q2.setBounds(0, 0, 134, 44);
      panel.add(q2);
      
      box1 = new JTextField();
      box1.setBounds(12, 492, 47, 49);
      panel.add(box1);
      box1.setColumns(10);
      
      box2 = new JTextField();
      box2.setColumns(10);
      box2.setBounds(73, 492, 47, 49);
      panel.add(box2);
      
      box3 = new JTextField();
      box3.setColumns(10);
      box3.setBounds(132, 492, 47, 49);
      panel.add(box3);
      
      box4 = new JTextField();
      box4.setColumns(10);
      box4.setBounds(191, 492, 47, 49);
      panel.add(box4);
      
      JLabel arrow1 = new JLabel("\u2192");
      arrow1.setBounds(59, 509, 18, 15);
      panel.add(arrow1);
      
      JLabel arrow2 = new JLabel("\u2192");
      arrow2.setBounds(116, 508, 18, 16);
      panel.add(arrow2);
      
      JLabel arrow3 = new JLabel("\u2192");
      arrow3.setBounds(178, 504, 18, 24);
      panel.add(arrow3);
      JButton btnNewButton_1 = new JButton("Check");
      btnNewButton_1.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) 
         {
            
            if(box1.getText().equals("3")&&box2.getText().equals("2")&&box3.getText().equals("1")&&box4.getText().equals("4"))
            { //3->2->1->4
               JOptionPane.showMessageDialog(null, "Correct!");
               	dispose();
               	
   				HardQuiz_3 h3=new HardQuiz_3();
   				
            }
            else
            {
               JOptionPane.showMessageDialog(null, "Wrong!");
            }
         }
      });
      btnNewButton_1.setBounds(371, 492, 79, 49);
      panel.add(btnNewButton_1);

   }
}