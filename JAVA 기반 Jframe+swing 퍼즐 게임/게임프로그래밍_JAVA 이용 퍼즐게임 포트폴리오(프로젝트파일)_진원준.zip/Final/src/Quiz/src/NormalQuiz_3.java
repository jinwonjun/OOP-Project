package Quiz.src;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class NormalQuiz_3 extends JFrame {

   private JPanel contentPane;
   private JTextField box2;
   private JTextField box1;
   private JTextField box3;
   private JTextField box4;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               NormalQuiz_3 frame = new NormalQuiz_3();
               frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the frame.
    */
   public NormalQuiz_3() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 359, 495);
      contentPane = new JPanel();
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setLayout(new BorderLayout(0, 0));
      setContentPane(contentPane);
      
      JPanel panel = new JPanel();
      contentPane.add(panel, BorderLayout.CENTER);
      panel.setLayout(null);
      JLabel lblNewLabel_5 = new JLabel("(4)main");
      lblNewLabel_5.setBounds(104, 339, 116, 15);
      panel.add(lblNewLabel_5);
      
      JLabel lblNewLabel_4 = new JLabel("(3)(String[] args)");
      lblNewLabel_4.setBounds(104, 314, 114, 15);
      panel.add(lblNewLabel_4);
      
      JLabel lblNewLabel_3 = new JLabel("(2)public static");
      lblNewLabel_3.setBounds(104, 289, 114, 15);
      panel.add(lblNewLabel_3);
      
      JLabel lblNewLabel_2 = new JLabel("(1)void");
      lblNewLabel_2.setBounds(104, 264, 67, 15);
      panel.add(lblNewLabel_2);
      
      JLabel q2 = new JLabel("Question2");
      q2.setFont(new Font("�޸�����ü", Font.PLAIN, 20));
      q2.setBounds(0, 0, 108, 44);
      panel.add(q2);
      
      JLabel hellopic = new JLabel("");
      hellopic.setIcon(new ImageIcon("src/res/NormalQuiz_3.png"));
      hellopic.setBounds(0, 20, 320, 301);
      panel.add(hellopic);
      
      JLabel q2problem = new JLabel("Arrange to match order in blank");
      q2problem.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
      q2problem.setBounds(0, 51, 281, 15);
      panel.add(q2problem);
      
    
      
      box1 = new JTextField();
      box1.setColumns(10);
      box1.setBounds(0, 387, 47, 49);
      panel.add(box1);
      
      box2 = new JTextField();
      box2.setBounds(61, 387, 47, 49);
      panel.add(box2);
      box2.setColumns(10);
      
    
      box3 = new JTextField();
      box3.setColumns(10);
      box3.setBounds(120, 387, 47, 49);
      panel.add(box3);
      
      box4 = new JTextField();
      box4.setColumns(10);
      box4.setBounds(179, 387, 47, 49);
      panel.add(box4);
      
      JLabel arrow1 = new JLabel("\u2192");
      arrow1.setBounds(47, 404, 18, 15);
      panel.add(arrow1);
      
      JLabel arrow2 = new JLabel("\u2192");
      arrow2.setBounds(104, 403, 18, 16);
      panel.add(arrow2);
      
      JLabel arrow3 = new JLabel("\u2192");
      arrow3.setBounds(166, 399, 18, 24);
      panel.add(arrow3);
      
      JButton btnNewButton_1 = new JButton("Check");
      btnNewButton_1.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) 
         {
        	 System.out.println(box1.getText());
        	 System.out.println(box2.getText());
        	 System.out.println(box3.getText());
        	 System.out.println(box4.getText());
        	 
            if((box1.getText().equals("2"))&&(box2.getText().equals("1"))&&(box3.getText().equals("4"))&&(box4.getText().equals("3")))
            {    //answer = 2->1->4->3
            	System.out.println("correct");
            	JOptionPane.showMessageDialog(null,"Correct!");
            	dispose();
    			NormalQuiz_4 n4=new NormalQuiz_4();
    		
            }
            else
            {
               JOptionPane.showMessageDialog(null,"Wrong!");
            }
        }
      });
      btnNewButton_1.setBounds(254, 387, 79, 49);
      panel.add(btnNewButton_1);
   }
}