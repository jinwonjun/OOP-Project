package Quiz.src;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class NormalQuiz_2 extends JFrame implements ActionListener{

   private JPanel contentPane;
   private JTextField box2;
   private JTextField box1;
   private JTextField box3;
   private JTextField box4;

   /**
    * Launch the application.
    */
   static NormalQuiz_2 frame;
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            
               frame = new NormalQuiz_2();
               frame.setVisible(true);
                     }
      });
   }

   /**
    * Create the frame.
    */
   public NormalQuiz_2() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 359, 495);
      contentPane = new JPanel();
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setLayout(new BorderLayout(0, 0));
      setContentPane(contentPane);
      
      JPanel panel = new JPanel();
      contentPane.add(panel, BorderLayout.CENTER);
      panel.setLayout(null);
      
      JLabel lblNewLabel_5 = new JLabel("(4)(\"Hello World:)\");");
      lblNewLabel_5.setBounds(104, 254, 148, 15);
      panel.add(lblNewLabel_5);
      
      JLabel lblNewLabel_4 = new JLabel("(3)println");
      lblNewLabel_4.setBounds(104, 229, 67, 15);
      panel.add(lblNewLabel_4);
      
      JLabel lblNewLabel_3 = new JLabel("(2)out");
      lblNewLabel_3.setBounds(104, 204, 57, 15);
      panel.add(lblNewLabel_3);
      
      JLabel lblNewLabel_2 = new JLabel("(1)System");
      lblNewLabel_2.setBounds(104, 179, 67, 15);
      panel.add(lblNewLabel_2);
      
      JLabel q2 = new JLabel("Question2");
      q2.setFont(new Font("�޸�����ü", Font.PLAIN, 20));
      q2.setBounds(0, 0, 122, 44);
      panel.add(q2);
      
      JLabel hellopic = new JLabel("");
      hellopic.setIcon(new ImageIcon("src/res/NormalQuiz_2.png"));
      hellopic.setBounds(61, 76, 217, 301);
      panel.add(hellopic);
      
      JLabel q2problem = new JLabel("Arrange to match order to print 'Hello world:)'");
      q2problem.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
      q2problem.setBounds(0, 51, 400, 15);
      panel.add(q2problem);
      
    
      
      box1 = new JTextField();
      box1.setColumns(10);
      box1.setBounds(0, 387, 47, 49);
      panel.add(box1);
      
      box2 = new JTextField();
      box2.setBounds(61, 387, 47, 49);
      panel.add(box2);
      box2.setColumns(10);
      
    
      box3 = new JTextField();
      box3.setColumns(10);
      box3.setBounds(120, 387, 47, 49);
      panel.add(box3);
      
      box4 = new JTextField();
      box4.setColumns(10);
      box4.setBounds(179, 387, 47, 49);
      panel.add(box4);
      
      JLabel arrow1 = new JLabel("\u2192");
      arrow1.setBounds(47, 404, 18, 15);
      panel.add(arrow1);
      
      JLabel arrow2 = new JLabel("\u2192");
      arrow2.setBounds(104, 403, 18, 16);
      panel.add(arrow2);
      
      JLabel arrow3 = new JLabel("\u2192");
      arrow3.setBounds(166, 399, 18, 24);
      panel.add(arrow3);
      JButton btnNewButton_1 = new JButton("Check");
      btnNewButton_1.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) 
         {
        	 System.out.println(box1.getText());
        	 System.out.println(box2.getText());
        	 System.out.println(box3.getText());
        	 System.out.println(box4.getText());
        	 NormalQuiz_3 n=new NormalQuiz_3();
            if((box1.getText().equals("1"))&&(box2.getText().equals("2"))&&(box3.getText().equals("3"))&&(box4.getText().equals("4")))
            {
            	System.out.println("correct");
            	JOptionPane.showMessageDialog(null,"Correct!");
            	frame.setVisible(false);
    			NormalQuiz_3 n3=new NormalQuiz_3();
    			n3.main(null);
            }
            else
            {
               JOptionPane.showMessageDialog(null,"Wrong!");
            }
        }
      });
      btnNewButton_1.setBounds(254, 387, 79, 49);
      panel.add(btnNewButton_1);
   }

@Override
public void actionPerformed(ActionEvent ev) {
	// TODO Auto-generated method stub
	
}
}