package Quiz.src;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import GUI.Start;
import Password.Password;



public class EasyQuiz_3 extends JFrame {

	JPanel jp = new JPanel();
	JButton button;

	JLabel l1;
	JLabel l2;
	JLabel l3;

	JButton b1;
	JButton b2;
	JButton b3;

	JTextField t1;
	JTextField t2;
	JTextField t3;

	int normalPass;

	public EasyQuiz_3() {
		Password pass = Password.getPass();
		normalPass = pass.getNormal();
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(0, 0, 500, 473);
		jp.setLayout(new BoxLayout(jp, BoxLayout.Y_AXIS));
		this.setContentPane(jp);

		// random show problem you will add, or using file I/O more sentence
		// able to add
		int i = ((int) (Math.random() * 10) / 4);
		String[] text = { ("int x=3;"), ("double y=3.14;"), ("long z=123;"), ("short s=1;") };

		JLabel p = new JLabel("Write codes correctly.");
		p.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
		jp.add(p);
		jp.add(l1 = new JLabel(text[i]));
		JTextField t1 = new JTextField(20);
		t1.setBounds(50, 100, 20, 20);
		jp.add(t1);
		jp.add(button = new JButton("Submit"));
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (t1.getText().equals(l1.getText())) {
					JOptionPane.showMessageDialog(jp, "Correct! next Stage's PASSWORD" + "  " + normalPass);
					new Start();
					dispose();
				} else {
					JOptionPane.showMessageDialog(jp, "Wrong!");
				}
			}
		});

		this.setVisible(true);

	}

}
