package Quiz.src;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import GUI.Start;

public class HardQuiz_3 extends JFrame {

   JPanel jp = new JPanel();   
   JButton button ;
   
   
   JLabel l1;
   JLabel l2;
   JLabel l3;
   
   JButton b1;
   JButton b2;
   JButton b3;
   
   JTextField t1;
   JTextField t2;
   JTextField t3;
   
   
   
   public HardQuiz_3(){
      this.setResizable(false);
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setBounds(0, 0, 500, 473);
      jp.setLayout(new BoxLayout(jp,BoxLayout.Y_AXIS));
      int i = ((int)(Math.random()*10)/4);
      System.out.println(i);
      
      String[] text={("for(int i=0; i<10; i++)"),("while(x<10){System.out.println(x);x++;}"),("switch(i){case 1: System.out.println(x);break;default : break;}"),("if(i==3){System.out.println(x);}else{return 0;}")};
      
      this.setContentPane(jp);
      jp.add(l1=new JLabel(text[i]));
      JTextField t1 = new JTextField(30);
      t1.setBounds(50, 100, 100, 20);
      jp.add(t1);
      jp.add(button = new JButton("Submit"));
      button.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            if(t1.getText().equals(l1.getText())){
               JOptionPane.showMessageDialog(jp, "Correct!");
               new Start();
   			   dispose();
            }else{
               JOptionPane.showMessageDialog(jp, "Wrong!");
            }
         }
      });
      
      this.setVisible(true);
      
      
   }
}