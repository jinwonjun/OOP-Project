package Quiz.src;


import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class EasyQuiz_1 extends JFrame implements ActionListener,ItemListener{
		int answer=1; //1,2,3,4 �� ���ϴ� �� ������ ����
		int choosed;
		JFrame frame;
		JRadioButton check1;
		JRadioButton check2;
		JRadioButton check3;
		JRadioButton check4;
		JLabel label;
		private final ButtonGroup buttonGroup = new ButtonGroup();
		
	public EasyQuiz_1(){
		frame = new JFrame();
		JButton button = new JButton("Submit");
		button.addActionListener(this);
		check1 = new JRadioButton("int x=1;");
		buttonGroup.add(check1);
		check2 = new JRadioButton("long y=10.44");
		buttonGroup.add(check2);
		check3 = new JRadioButton("double x=123123123123123123123");
		buttonGroup.add(check3);
		check4 = new JRadioButton("short w= 99999999;");
		buttonGroup.add(check4);
		label = new JLabel();	
		check1.addItemListener(this);
		check2.addItemListener(this);
		check3.addItemListener(this);
		check4.addItemListener(this);
		Container pane = frame.getContentPane();
		pane.setLayout(new BoxLayout(pane,BoxLayout.Y_AXIS));
		JLabel q=new JLabel("Question1");
		q.setFont(new Font("�޸�����ü", Font.PLAIN, 20));
		pane.add(q);
		JLabel p=new JLabel("Choosing right code.");
		p.setFont(new Font("�޸�����ü", Font.PLAIN, 16));
		pane.add(p);
		pane.add(check1);
		pane.add(check2);
		pane.add(check3);
		pane.add(check4);
		pane.add(button);
		pane.add(label);
		frame.setSize(500, 500);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(choosed==answer){
			JOptionPane.showMessageDialog(null,"Correct!");
			frame.setVisible(false);
			EasyQuiz_2 q=new EasyQuiz_2();
			q.main(null);
		}
		else if(choosed==2){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"long can't use the real number.\n"+"Try again");
			
		}
		else if(choosed==3){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"Maximum number that long can use is 9223372036854775807.\n"+"Try again");
		}
		else if(choosed==4){
			JOptionPane.showMessageDialog(null,"Wrong answer!\n"+"Maximum number that short can use is 32767\n"+"Try again");
		}
	}

	
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
		if (check1.isSelected()){
			choosed=1;
		}
		if (check2.isSelected()){
			choosed=2;
		}
		if(check3.isSelected()){
			choosed=3;
		}
		if(check4.isSelected()){
			choosed=4;
		}
	}
	
}
