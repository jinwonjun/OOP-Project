package NormalConcept;


import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Interface.PInterface;
import javax.swing.ImageIcon;



/**
 * about Normal's methodConcept panel
 * 
 * @author PPPSH
 *
 */
public class methodConcept extends JPanel implements PInterface{

	private JPanel panel= new JPanel();

	
	public methodConcept() {
		panel.setBounds(538, 50, 435, 410);
		panel.setLayout(null);
		
		JLabel IdeaTitle1 = new JLabel("What is");
		IdeaTitle1.setFont(new Font("�޸�����ü", Font.BOLD, 25));
		IdeaTitle1.setBounds(0, 0, 94, 42);
		panel.add(IdeaTitle1);
		
		JLabel IdeaTitle2 = new JLabel("method?");
		IdeaTitle2.setForeground(Color.BLUE);
		IdeaTitle2.setFont(new Font("�޸�����ü", Font.BOLD, 30));
		IdeaTitle2.setBounds(97, 0, 151, 43);
		panel.add(IdeaTitle2);
		
		JButton btnNewButton1 = new JButton("Play!");
		btnNewButton1.setBounds(10, 54, 94, 87);
		panel.add(btnNewButton1);
		
		JButton btnNewButton2 = new JButton("Play!");
		btnNewButton2.setBounds(10, 54, 94, 87);
		panel.add(btnNewButton2);
		
		JLabel mill = new JLabel("");
		mill.setIcon(new ImageIcon("src/res/wheat.png"));
		mill.setBounds(116, 53, 94, 87);
		mill.setVisible(false);
		panel.add(mill);
		
		JLabel upArrow = new JLabel("");
		upArrow.setIcon(new ImageIcon("src/res/arrow.png"));
		upArrow.setBounds(161, 150, 25, 33);
		upArrow.setVisible(false);
		panel.add(upArrow);
		
		JLabel factory = new JLabel("");
		factory.setIcon(new ImageIcon("src/res/factory.png"));
		factory.setBounds(127, 165, 208, 110);
		panel.add(factory);
		
		JLabel cake = new JLabel("");
		cake.setIcon(new ImageIcon("src/res/cakesize.png"));
		cake.setBounds(232, 276, 107, 134);
		cake.setVisible(false);
		panel.add(cake);
		
		JLabel downArrow = new JLabel("");
		downArrow.setIcon(new ImageIcon("src/res/arrow.png"));
		downArrow.setBounds(266, 257, 25, 33);
		downArrow.setVisible(false);
		panel.add(downArrow);
		
		btnNewButton1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getSource()==btnNewButton1)
				{
					upArrow.setVisible(true);
					mill.setVisible(true);
					
					btnNewButton1.setVisible(false);
					btnNewButton2.setVisible(true);
				}
			}
		});
		btnNewButton2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getSource()==btnNewButton2)
				{
					downArrow.setVisible(true);
					cake.setVisible(true);
					
				}
			}
		});
		
	}
	
	public JPanel getPanel(){
		return this.panel;
	}

}