package Password;



/**
 * Using Singleton pattern, other class don't create password, 
 * and don't change because don't make setter; 
 * @author PPPSH
 *
 */

public class Password {
	private static Password pass = new Password();
	private int normalPass;
	private int hardPass;
	
	private Password(){
		normalPass = (int)(Math.random()*10000); // random 
		hardPass = (int)(Math.random()*10000);   //
			
	}
	
	public static Password getPass(){
		return pass;
	}
	
	public int getNormal(){
		return normalPass;
	}
	
	public int getHard(){
		return hardPass;
	}
	
}
