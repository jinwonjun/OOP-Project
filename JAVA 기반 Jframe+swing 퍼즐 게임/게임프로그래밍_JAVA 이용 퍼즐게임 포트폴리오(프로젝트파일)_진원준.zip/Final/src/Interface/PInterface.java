package Interface;

import javax.swing.JPanel;

public interface PInterface {
	public JPanel getPanel();
}
